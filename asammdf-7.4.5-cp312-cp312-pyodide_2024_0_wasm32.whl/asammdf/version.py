""" asammdf version module """

__version__ = "7.4.5"
