""" asammdf tool module """

from .version import __version__ as __version__

__tool__ = "asammdf"
__vendor__ = "asammdf"
